export default function PaymentPage() {
  return null;
}