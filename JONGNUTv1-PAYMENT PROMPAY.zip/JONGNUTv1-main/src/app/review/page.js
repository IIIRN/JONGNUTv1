// src/app/review/page.js
export default function ReviewLoadingPage() {
  return null;
}